# Clau Estética

Landing page estática pronta para GitHub Pages, com a marca em texto no cabeçalho.

1. Envie todos os arquivos desta pasta ao repositório.
2. Abra **Settings → Pages** no GitHub.
3. Escolha a branch principal e a pasta **/(root)**.
